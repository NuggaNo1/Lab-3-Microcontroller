/*
 * fsm_automatic.h
 *
 *  Created on: Oct 31, 2024
 *      Author: Admin
 */


#ifndef INC_FSM_AUTOMATIC_H_
#define INC_FSM_AUTOMATIC_H_


#include "TrafficLight.h"
#include "global.h"

void fsm1_automatic_run();
void fsm2_automatic_run();

#endif /* INC_FSM_AUTOMATIC_H_ */
