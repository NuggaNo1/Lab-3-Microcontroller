/*
 * fsm_modify_timer_control.h
 *
 *  Created on: Oct 31, 2024
 *      Author: Admin
 */

#ifndef INC_FSM_MODIFY_TIMER_CONTROL_H_
#define INC_FSM_MODIFY_TIMER_CONTROL_H_

#include "TrafficLight.h"
#include "global.h"

void fsm_modify_timer_control();

#endif /* INC_FSM_MODIFY_TIMER_CONTROL_H_ */
